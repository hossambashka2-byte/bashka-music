
// BASHKA STORE SW - Play Store Ready
const CACHE_NAME = 'bashka-store-v1';
const APP_SHELL = [
  './',
  './index.html',
  './offline.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './bashka.jpg',
  './player-avatar.jpg'
];

// تثبيت - خزن واجهة التطبيق فقط (ما كل الأغاني)
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(()=>self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())
  );
});

// استراتيجية: App Shell من الكاش، الأغاني من الشبكة مع تخزين تدريجي
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  
  // لو طلب أغنية MP3 - خزنها بعد أول تشغيل للأوفلاين
  if(url.pathname.includes('.mp3') || e.request.url.includes('supabase') && e.request.url.includes('audio')){
    e.respondWith(
      caches.match(e.request).then(cached => {
        if(cached) return cached;
        return fetch(e.request).then(res => {
          if(res.ok){
            let clone = res.clone();
            caches.open(CACHE_NAME).then(c => c.put(e.request, clone));
          }
          return res;
        }).catch(()=> cached);
      })
    );
    return;
  }
  
  // باقي الملفات - Cache first
  e.respondWith(
    caches.match(e.request).then(cached => {
      if(cached) return cached;
      return fetch(e.request).then(res => {
        // خزن الصور والملفات المهمة
        if(res.ok && e.request.method==='GET'){
          let clone=res.clone();
          caches.open(CACHE_NAME).then(c=>c.put(e.request, clone));
        }
        return res;
      }).catch(() => {
        // لو فشل وده تنقل بين الصفحات، رجع offline.html
        if(e.request.mode === 'navigate'){
          return caches.match('./offline.html');
        }
      });
    })
  );
});

// للإشعارات - استقبال Push
self.addEventListener('push', e => {
  let data = {title:'BASHKA MUSIC', body:'أغنية جديدة من محمد عباس! 🎵'};
  try{ if(e.data) data = e.data.json(); }catch(err){}
  e.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: './icon-192.png',
      badge: './icon-192.png',
      vibrate: [200,100,200],
      data: {url: './'}
    })
  );
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow(e.notification.data.url || './'));
});
